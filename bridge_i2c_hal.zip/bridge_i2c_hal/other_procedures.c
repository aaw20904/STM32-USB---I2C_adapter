///--ISR for interrupt  SPI transaction

void SPI1_IRQHandler(void)
{
  /* USER CODE BEGIN SPI1_IRQn 0 */


  if(SPI1->CR1 & SPI_CR1_MSTR){
	  //when MASTER mode
		if ( (SPI1->SR & SPI_SR_TXE) && (SPI1->CR1 & SPI_CR1_BIDIOE) ) {

				//have all the data been transmitted?

				if (spiMasterHeader.spiTxMasterIndex >= spiMasterHeader.spiMasterTxPacketLength) {
					//clear structure
					spiMasterHeader.spiTxMasterIndex = 0;
					spiMasterHeader.spiMasterTxPacketLength =0;
					   //disable interrupts on Tx
						SPI1->CR2 &= ~SPI_CR2_TXEIE;
					//clear semaphore
					adapterSemaphoreSPI &= 0xfffffffe; //clear bit 0

					return;
				}

				//a)write a new data in DR (it clears the flag)
				spiMasterHeader.hDevice->DR = spiMasterHeader.spiTxMasterBuffer[spiMasterHeader.spiTxMasterIndex];
				//b) increase array index
				spiMasterHeader.spiTxMasterIndex++;

		}

		if (spiMasterHeader.hDevice->SR & SPI_SR_RXNE) {
			//a)write a new data in DR (it clears the flag)
			  spiMasterHeader.spiRxMasterBuffer[spiMasterHeader.spiRxMasterIndex] = spiMasterHeader.hDevice->DR;
			//b) increase array index
			spiMasterHeader.spiRxMasterIndex++;

			if (spiMasterHeader.spiRxMasterIndex >= spiMasterHeader.spiMasterRxPacketLength) {
					//clear structure
					spiMasterHeader.spiRxMasterIndex = 0;
					spiMasterHeader.spiMasterRxPacketLength =0;
					  //disable interrupts on Rx
					 SPI1->CR2 &= ~SPI_CR2_RXNEIE;
					//clear semaphore
					adapterSemaphoreSPI &= 0xfffffffe; //clear bit 0
					return;
			}

		}

  }


  /* USER CODE END SPI1_IRQn 0 */
  /* USER CODE BEGIN SPI1_IRQn 1 */

  /* USER CODE END SPI1_IRQn 1 */
}

 //functions for interrupt transactions
int32_t masterWriteSpiTransaction(volatile wrp_spi_master_header* spiHeader){
	adapterSemaphoreSPI &= 0xfffffffe; //clear bit 0
	adapterSemaphoreSPI |= 0x00000001;
	spiHeader->spiMasterErrorFlags = 0;
	//-------------------------------------------
	//a) disable SPI
	spiHeader->hDevice->CR1 &= ~SPI_CR1_SPE;
	//change configuration to transmitter
	spiHeader->hDevice->CR1 |= SPI_CR1_BIDIOE;
	   //enable interrupts on Tx
	spiHeader->hDevice->CR2 |= SPI_CR2_TXEIE;
    //a) write the first bye into DR
	spiHeader->hDevice->DR =  spiHeader->spiTxMasterBuffer[ spiHeader->spiTxMasterIndex];
    //b) Increase index
	spiHeader->spiTxMasterIndex++;
    //set SS signal in active state
	 setSlaveSelectSPI(spiHeader->ssPolarity);
	 dummyDelay(10);
	  //c)enable peripherial - start SPI transaction
	 spiHeader->hDevice->CR1 |= SPI_CR1_SPE;

    while(adapterSemaphoreSPI & 0x00000001){
     //wait until sends txPacketLength-1 bytes
    }
    while(spiHeader->hDevice->SR & SPI_SR_BSY){
    //wait until last byte has been sent
    }

    dummyDelay(10);
    //clear SS signal to inactive
	 clearSlaveSelectSPI(spiHeader->ssPolarity);
	//when all the data has been transmitted - turn the peripherial off
	 spiHeader->hDevice->CR1 &= ~SPI_CR1_SPE;
		//clear TXE flag
	 spiHeader->hDevice->DR = 0x00;
	 //
	return spiHeader->spiMasterErrorFlags;
}


int32_t masterReadSpiTransaction(volatile wrp_spi_master_header* spiHeader){

	adapterSemaphoreSPI &= 0xfffffffe; //clear bit 0
	adapterSemaphoreSPI |= 0x00000001;
	spiHeader->spiMasterErrorFlags = 0;
	//-------------------------------------------
	//a) disable SPI
	spiHeader->hDevice->CR1 &= ~SPI_CR1_SPE;

	//change configuration to receiver
	spiHeader->hDevice->CR1 &= ~SPI_CR1_BIDIOE;

	   //enable interrupts on Rx
	spiHeader->hDevice->CR2 |= SPI_CR2_RXNEIE;

    //set SS signal in active state
	 setSlaveSelectSPI(spiHeader->ssPolarity);
	 dummyDelay(10);
	  //c)enable peripherial - start SPI transaction
	 spiHeader->hDevice->CR1 |= SPI_CR1_SPE;


    while(adapterSemaphoreSPI & 0x00000001){
     //wait until sends txPacketLength-1 bytes
    }
    while(spiHeader->hDevice->SR & SPI_SR_BSY){
    //wait until last byte has been sent
    }

    //when all the data has been transmitted - turn the peripherial off
    	 spiHeader->hDevice->CR1 &= ~SPI_CR1_SPE;
    dummyDelay(10);
    //clear SS signal to inactive
	 clearSlaveSelectSPI(spiHeader->ssPolarity);

		//clear RXNE flag
	 //spiHeader->hDevice->DR = 0x00;
	 //
	return spiHeader->spiMasterErrorFlags;
}
 